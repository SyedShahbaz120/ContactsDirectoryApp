// Code By Syed Shahbaz
//Student Number : 1195561
import SwiftUI

struct ContactDetail: View {
    let contact: Contact
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(contact.fullName).font(.largeTitle)
            if contact.isFavorite {
                Image(systemName: "star.fill").foregroundColor(.yellow).font(.largeTitle)
            } else {
                Image(systemName: "star").foregroundColor(.gray).font(.headline)
            }
            Divider()
            HStack {
                Text("Phone").foregroundColor(.black)
                Spacer()
                Text(contact.phone).foregroundColor(.gray)
            }
            Divider()
            HStack {
                Text("Email").foregroundColor(.black)
                Spacer()
                Text(contact.email).foregroundColor(.gray)
            }
            Divider()
            HStack {
                Text("Address").foregroundColor(.black)
                Spacer()
                Text(contact.fullAddress).foregroundColor(.gray)
            }
            Divider()
        }
        .padding()
        .navigationTitle("Contacts")
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    ContactDetail(contact: ContactStore.testStore.contacts[0])
}
