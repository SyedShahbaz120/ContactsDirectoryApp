// Code By Syed Shahbaz
//Student Number : 1195561
import SwiftUI

struct ContactsListView: View {
    @State var viewModel: ContactsListViewModel
    
    var body: some View {
          NavigationView {
              List {
                  ForEach(viewModel.listData) { contact in
                      NavigationLink(destination: ContactDetail(contact: contact)) {
                          ContactRow(contact: contact)
                      }
                  }
                  .onMove(perform: viewModel.moveContacts)
                  .onDelete(perform: viewModel.deleteContacts)
                  
                  HStack {
                      Spacer()
                      Text(viewModel.displayCount)
                          .foregroundColor(.secondary)
                      Spacer()
                  }
              }
              .navigationTitle(viewModel.navTitle)
              .searchable(text: $viewModel.searchTerm, placement: .navigationBarDrawer(displayMode: .automatic), prompt: "Search for Contacts")
              .onChange(of: viewModel.searchTerm) {
                  viewModel.filterSearchResults()
              }
              .toolbar {
                  ToolbarItem(placement: .navigationBarTrailing) {
                      Button("Add") {
                          withAnimation {
                              viewModel.addContact()
                          }
                      }
                  }
                  
                  ToolbarItem(placement: .navigationBarTrailing) {
                      EditButton()
                  }
                  
                  ToolbarItem(placement: .navigationBarTrailing) {
                      Button("Reset") {
                          withAnimation {
                              viewModel.resetContacts()
                          }
                      }
                  }
              }
          }
      }
  }


#Preview {
    ContactsListView(viewModel: ContactsListViewModel())
}
