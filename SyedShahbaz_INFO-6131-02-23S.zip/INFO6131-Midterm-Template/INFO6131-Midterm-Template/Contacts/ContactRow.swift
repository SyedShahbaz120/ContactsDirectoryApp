// Code By Syed Shahbaz
//Student Number : 1195561
import SwiftUI

struct ContactRow: View {
    let contact: Contact
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(contact.fullName).font(.headline)
                if contact.isFavorite {
                    Image(systemName: "star.fill").foregroundColor(.yellow)
                }
            }
            Spacer()
            Image(systemName: "chevron.right")
        }
    }
}

#Preview {
    ContactRow(contact: ContactStore.testStore.contacts[1])
}
