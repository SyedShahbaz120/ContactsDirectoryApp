// Code By Syed Shahbaz
//Student Number : 1195561
import SwiftUI
import Observation

@Observable
final class ContactsListViewModel {
    // Properties
    var store: ContactStore
    var navTitle: String = "Contacts"
    var searchTerm: String = ""
    var searchResults: [Contact] = []
    
    // Computed Properties
    var listData: [Contact] {
        searchTerm.isEmpty ? store.contacts : searchResults
    }
    
    var displayCount: String {
        "\(listData.count) contacts"
    }
    
    init(store: ContactStore = ContactStore.testStore) {
        self.store = store
    }
    
    // Methods
    func filterSearchResults() {
        searchResults = store.contacts.filter {
            $0.fullName.localizedCaseInsensitiveContains(searchTerm)
        }
    }
    
    func addContact() {
        guard let randomContact = store.contacts.randomElement() else {
            return
        }
        store.contacts.append(randomContact)
    }
    
    func resetContacts() {
        store.contacts = ContactStore.mockData
    }
    
    func deleteContacts(offset: IndexSet) {
        store.contacts.remove(atOffsets: offset)
    }
    
    func moveContacts(from: IndexSet, to: Int) {
        store.contacts.move(fromOffsets: from, toOffset: to)
    }
}
