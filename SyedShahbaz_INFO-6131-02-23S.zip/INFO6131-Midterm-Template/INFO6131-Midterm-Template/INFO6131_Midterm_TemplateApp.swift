// Code By Syed Shahbaz
//Student Number : 1195561
import SwiftUI

@main
struct INFO6131_Midterm_TemplateApp: App {
    var body: some Scene {
        WindowGroup {
            ContactsListView(viewModel: ContactsListViewModel())
        }
    }
}


